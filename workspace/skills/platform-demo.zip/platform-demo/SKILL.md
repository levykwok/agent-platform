---
name: platform-demo
description: Demo skill for verifying platform skill wiring.
---

# Platform Demo Skill

Use this skill when validating that the platform can register skills, bind them to an agent, and expose them to the AgentScope runtime.

When loaded, answer with the specific checks performed:

- The skill registry entry exists.
- The skill location resolves under the platform workspace.
- The agent includes this skill through `skillRefs`.
- The runtime can load `SKILL.md` through AgentScope skill support.
